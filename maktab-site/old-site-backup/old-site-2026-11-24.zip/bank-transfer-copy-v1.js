(() => {
  document.addEventListener('click', async event => {
    const button = event.target.closest?.('#bank-transfer button[data-copy]');
    if (!button) return;
    const card = button.closest('#bank-transfer');
    const fields = [...card.querySelectorAll('dl > div')];
    const field = button.closest('dl > div');
    const text = field
      ? field.querySelector('dd').textContent.trim()
      : fields.map(row => row.querySelector('dt').textContent + ': ' + row.querySelector('dd').textContent.trim()).join('\n');
    const status = card.querySelector('[role=status]');
    const fa = document.documentElement.lang.startsWith('fa');
    try {
      await navigator.clipboard.writeText(text);
      status.textContent = fa ? 'کاپی شد.' : (field ? field.querySelector('dt').textContent + ' copied.' : 'Bank details copied.');
    } catch {
      const manual = card.querySelector('textarea');
      manual.hidden = false;
      manual.value = text;
      manual.focus();
      manual.select();
      status.textContent = fa ? 'متن انتخاب شده را کاپی کنید.' : 'Copy the selected text using your device’s Copy command.';
    }
  });
})();
